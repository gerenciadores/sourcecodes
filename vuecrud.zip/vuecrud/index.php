<!DOCTYPE html>
<html>
<head>
	<title>Vue.js CRUD Series using PHP/MySQLi</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
</head>
<body>
<div class="container">
	<h1 class="page-header text-center">Vue.js CRUD OPERATION with PHP/MySQLi</h1>
	<div id="members">
		<div class="col-md-8 col-md-offset-2">
			<div class="row">
				<div class="col-md-12">
					<h2>Member List
					<button class="btn btn-primary pull-right"><span class="glyphicon glyphicon-plus"></span> Member</button>
					</h2>
				</div>
			</div>
			<table class="table table-bordered table-striped">
				<thead>
					<th>Firstname</th>
					<th>Lastname</th>
					<th>Action</th>
				</thead>
				<tbody>
					<tr v-for="member in members">
						<td>{{ member.firstname }}</td>
						<td>{{ member.lastname }}</td>
						<td>
							<button class="btn btn-success"><span class="glyphicon glyphicon-edit"></span> Edit</button> <button class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</button>

						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>
<script src="vue.js"></script>
<script src="axios.js"></script>
<script src="app.js"></script>
</body>
</html>