<?php
	require'conn.php';
	
	if(ISSET($_POST['search'])){
		$keyword = $_POST['keyword'];
		$query=$conn->query("SELECT * FROM `member` WHERE `firstname` LIKE '%$keyword%' OR `lastname` LIKE '%$keyword%' OR `address` LIKE '%$keyword%'") or die("Failed to fetch row!");
		while($fetch=$query->fetchArray()){
			echo"<tr><td>".$fetch['firstname']."</td><td>".$fetch['lastname']."</td><td>".$fetch['address']."</td></tr>";
		}
	}else{
		$query=$conn->query("SELECT * FROM `member`") or die("Failed to fetch row!");
		while($fetch=$query->fetchArray()){
			echo"<tr><td>".$fetch['firstname']."</td><td>".$fetch['lastname']."</td><td>".$fetch['address']."</td></tr>";
		}
	}
?>