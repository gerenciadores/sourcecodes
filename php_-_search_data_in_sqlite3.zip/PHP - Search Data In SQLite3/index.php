<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
	</head>
<body>
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<a class="navbar-brand" href="https://sourcecodester.com">Sourcecodester</a>
		</div>
	</nav>
	<div class="col-md-3"></div>
	<div class="col-md-6 well">
		<h3 class="text-primary">PHP - Search Data In SQLite3</h3>
		<hr style="border-top:1px dotted #ccc;"/>
		<div class="col-md-4">
			<form method="POST" action="insert.php">
				<div class="form-group">
					<label>Firstname</label>
					<input type="text" class="form-control" name="firstname" required="required"/>
				</div>
				<div class="form-group">
					<label>Lastname</label>
					<input type="text" class="form-control" name="lastname" required="required"/>
				</div>
				<div class="form-group">
					<label>Address</label>
					<input type="text" class="form-control" name="address" required="required"/>
				</div>
				<center><button class="btn btn-primary" name="insert" >Insert</button></center>
			</form>
		</div>
		<div class="col-md-8">
			<form method="POST" class="form-inline" action="">
				<label>Search:</label>
				<input type="text" name="keyword" class="form-control" placeholder="Enter here..." required="required"/>
				<button class="btn btn-success" name="search"><span class="glyphicon glyphicon-search"></span> Search</button>
			</form>
			<br />
			<table class="table table-bordered">
				<thead class="alert-info">
					<tr >
						<th>Firstname</th>
						<th>Lastname</th>
						<th>Address</th>
					</tr>
				</thead>
				<tbody>
					<?php include'search_data.php'?>
				</tbody>
			</table>
		</div>
	</div>
</body>	
</html>